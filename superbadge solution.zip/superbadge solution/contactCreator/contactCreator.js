import { LightningElement, wire,api } from 'lwc';
import CONTACT_OBJECT from '@salesforce/schema/Contact'
import FIRST_NAME_FIELD from '@salesforce/schema/Contact.FirstName';
import LAST_NAME_FIELD from '@salesforce/schema/Contact.LastName';
import EMAIL_FIELD from '@salesforce/schema/Contact.Email';
import {ShowToastEvent} from 'lightning/platformShowToastEvent'

export default class ContactCreator extends LightningElement {

    @api recordId
objectApiName=CONTACT_OBJECT
fields=[FIRST_NAME_FIELD,LAST_NAME_FIELD,EMAIL_FIELD]


handleSuccess(event){
    let toastEvent=new ShowToastEvent({
        title:"Contact Created",
        message:"Id" +event.detail.id,
        variant:"success"
    });
    this.dispatchEvent(toastEvent);
}














}